/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hashtable_y_Arboles;

import EDD.Habitaciones;
import EDD.Personas_hospedadas;

/**
 *
 * @author tomas
 */
public class Hashtable {
    
    int size = 1000;
    Personas_hospedadas[] hasht;
    
    public Hashtable() {
        hasht = new Personas_hospedadas[size];
    }
    
    public void insertar_P(int numhabitacion, String nombre, String apellido, String email, String genero, String tlf, String llegada, Habitaciones[] habit) {
        
        int hasht1 = (nombre.hashCode()+ apellido.hashCode()) % hasht.length;
        hasht1 = (hasht1 + hasht.length) % hasht.length;
        int hasht2 = (hasht1 * 13) % (hasht.length - 2) + 1;
        int indicador = hasht1;
        habit[numhabitacion - 1].setOcupado(true);
        while (hasht[indicador] != null) {
            indicador = (indicador + hasht2) % hasht.length;
            if (indicador == hasht1) {
                throw new IllegalStateException("El Hashtable se encuentre lleno.");
            }
        }
        hasht[indicador] = new Personas_hospedadas(numhabitacion, nombre, apellido, email, genero, tlf, llegada);
    }
    
    public Personas_hospedadas buscar_p(String nombre, String apellido) {
        int hasht1 = (nombre.hashCode()+ apellido.hashCode()) % hasht.length;
        int hasht2 = (hasht1 * 13) % (hasht.length - 2) + 1;

        int indicador = hasht1;
        while (hasht[indicador] != null) {
            if (hasht[indicador].getNombre().equals(nombre) && hasht[indicador].getApellido().equals(apellido)) {
                return hasht[indicador];
            }
            indicador = (indicador + hasht2) % hasht.length;
            if (indicador == hasht1) {
                break;
            }
        }
        return null;
    }
    
    public Habitaciones buscar_h(Habitaciones[] habit, String tipohabitacion){
        for (int i = 0; i < 300; i++) {
            if (habit[i].isOcupado()== false && habit[i].getTipohabitacion().equals(tipohabitacion)){
                return habit[i];
            }
        }
        return null;
    }
    
    public void eliminar_p(String nombre, String apellido, Habitaciones[] habit){
        int hasht1 = (nombre.hashCode()+ apellido.hashCode()) % hasht.length;
        int hasht2 = (hasht1 * 13) % (hasht.length - 2) + 1;

        int indicador = hasht1;
        while (hasht[indicador] != null) {
            if (hasht[indicador].getNombre().equals(nombre) && hasht[indicador].getApellido().equals(apellido)) {
                int nro = hasht[indicador].getNumhabitacion();
                habit[nro-1].setOcupado(false);
                hasht[indicador] = null;

            }
            indicador = (indicador + hasht2) % hasht.length;
            if (indicador == hasht1) {
                break;
            }
        }
    }
}
