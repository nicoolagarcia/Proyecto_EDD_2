/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hashtable_y_Arboles;

import EDD.Historial_hotel;

/**
 *
 * @author tomas
 */
public class Historial_ABB {

    int size = 300;
    private Historial_hotel[] hist;

    public Historial_ABB() {
        hist = new Historial_hotel[size];
    }

    public void busqueda_h(int id, String nombre, String apellido, String email, String genero, String llegada, int numhabitacion) {
        int indicador = numhabitacion;
        if (hist[indicador] == null) {
            hist[indicador] = new Historial_hotel(id, nombre, apellido, email, genero, llegada, numhabitacion);
        } else {
            Historial_hotel h_hotel = new Historial_hotel (id, nombre, apellido, email, genero, llegada, numhabitacion);
            insertar_tree(hist[indicador], h_hotel);
        }
    }

    private void insertar_tree(Historial_hotel nodo, Historial_hotel h_hotel) {

        if (h_hotel.getId() < nodo.getId()) {
            if (nodo.getLeft() == null) {
                nodo.setLeft(h_hotel);
            } else {
                insertar_tree(nodo.getLeft(), h_hotel);
            }
        } else if (h_hotel.getId() > nodo.getId()) {
            if (nodo.getRight() == null) {
                nodo.setRight(h_hotel);
            } else {
                insertar_tree(nodo.getRight(), h_hotel);
            }
        } else {}
    }

    public String Buscar_tree(Historial_hotel nodo, String i) {
        if (nodo == null) {
            return null;
        } else {
            if (nodo.getLeft()!= null){
                i += Buscar_tree(nodo.getLeft(), i);
            }
            if (nodo.getRight()!=null){
            i += Buscar_tree(nodo.getRight(), i);
            }
            i += "Cedula: "+nodo.getId()+ " | Nombre: " + nodo.getNombre()+ " | Apellido:  " + nodo.getApellido() + " | Email: " + nodo.getEmail() +" | Genero: " + nodo.getGenero() + " | Llegada: " + nodo.getLlegada() + " | Numero de Habitacion: " + nodo.getNumhabitacion() + "\n";
        }
        return i;
    }
    
    public Historial_hotel buscar_h(int numhabitacion){
        return hist[numhabitacion];
    }
    
    private int hash(int key) {
        return key % size;
    }
}
