/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Hashtable_y_Arboles;

import EDD.Nodo;

/**
 *
 * @author tomas
 */
public class Hashtable_ABB {
    
    int size = 1000;
    Nodo[] table;

    public Hashtable_ABB() {
        table = new Nodo[size];
    }

    public void busqueda_abb(int id, String nombre, String nombre2, String email, String genero, String tipohabitacion, String tlf, String llegada, String salida) {
        int indicador = hash(id);
        if (table[indicador] == null) {
            table[indicador] = new Nodo(id, nombre, nombre2, email, genero, tipohabitacion, tlf, llegada, salida);
        } else {
            Nodo i = new Nodo (id, nombre, nombre2, email, genero, tipohabitacion, tlf, llegada, salida);
            insertar_tree(table[indicador], i);
        }
    }

    private void insertar_tree(Nodo node, Nodo i) {
        if (i.getId() < node.getId()) {
            if (node.left == null) {
                node.left = i;
            } else {
                insertar_tree(node.left, i);
            }
        } else if (i.getId() > node.getId()) {
            if (node.right == null) {
                node.right = i;
            } else {
                insertar_tree(node.right, i);
            }
        } else {}
    }

    public Nodo get(int key) {
        int indicador = hash(key);
        return Buscar_tree(table[indicador], key);
    }

    private Nodo Buscar_tree(Nodo node, int key) {
        if (node == null) {
            return null;
        } else if (key == node.getId()) {
            return node;
        } else if (key < node.getId()) {
            return Buscar_tree(node.left, key);
        } else {
            return Buscar_tree(node.right, key);
        }
    }

    private int hash(int key) {
        return key % size;
    }
    
    public void eliminar_tree(int key) {
        int indicador = hash(key);
        Nodo parent = null;
        Nodo node = table[indicador];

        while (node != null) {
            if (key < node.getId()) {
                parent = node;
                node = node.left;
            } else if (key > node.getId()) {
                parent = node;
                node = node.right;
            } else {
                if (node.left == null && node.right == null) {
                    if (parent == null) {
                        table[indicador] = null;
                    } else if (node == parent.left) {
                        parent.left = null;
                    } else {
                        parent.right = null;
                    }
                } else if (node.left == null) {
                    if (parent == null) {
                        table[indicador] = node.right;
                    } else if (node == parent.left) {
                        parent.left = node.right;
                    } else {
                        parent.right = node.right;
                    }
                } else if (node.right == null) {
                    if (parent == null) {
                        table[indicador] = node.left;
                    } else if (node == parent.left) {
                        parent.left = node.left;
                    } else {
                        parent.right = node.left;
                    }
                } else {
                    Nodo successorParent = node;
                    Nodo successor = node.right;
                    while (successor.left != null) {
                        successorParent = successor;
                        successor = successor.left;
                    }
                    node.setId(successor.getId()); 
                    node = successor;
                    if (successor == successorParent.left) {
                        successorParent.left = successor.right;
                    } else {
                        successorParent.right = successor.right;
                    }
                }
                return;
            }
        }
    
    
}
}

