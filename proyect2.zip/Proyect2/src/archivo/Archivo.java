/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package archivo;

import com.opencsv.CSVReader;
import com.opencsv.CSVWriter;
import com.opencsv.exceptions.CsvValidationException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;


/**
 *
 * @author tomas
 */
public class Archivo {

    public static void guardarCSV(String[] encabezados, String[][] datos, String nombreArchivo) {
        try {
            // Crear instancia de CSVWriter
            CSVWriter writer = new CSVWriter(new FileWriter(nombreArchivo));

            // Escribir encabezados en el archivo CSV
            writer.writeNext(encabezados);

            // Escribir datos en el archivo CSV
            for (String[] fila : datos) {
                writer.writeNext(fila);
            }

            // Cerrar CSVWriter
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void leerCSV(String nombreArchivo) throws CsvValidationException {
        
        try {
            // Crear instancia de CSVReader
            CSVReader reader = new CSVReader(new FileReader(nombreArchivo));

            // Leer encabezados
            String[] encabezados = reader.readNext();
            System.out.println("Encabezados: ");
            for (String encabezado : encabezados) {
                System.out.print(encabezado + " ");
            }
            System.out.println();

            // Leer datos de cada fila
            String[] fila;
            while ((fila = reader.readNext()) != null) {
                System.out.println("Fila: ");
                for (String dato : fila) {
                    System.out.print(dato + " ");
                }
                System.out.println();
            }

            // Cerrar CSVReader
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

