/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDD;

/**
 *
 * @author tomas
 */
public class Historial_hotel {

    Historial_hotel next;
    int id;
    String nombre;
    String apellido;
    String email;
    String genero;
    String llegada;
    int numhabitacion;

    Historial_hotel left;
    Historial_hotel right;
    int size;
    
    public Historial_hotel (int id, String nombre, String apellido, String email, String genero, String llegada, int numhabitacion){
        this.id = id;
        this.nombre = nombre;
        this.apellido = apellido;
        this.email = email;
        this.genero = genero;
        this.llegada = llegada;
        this.numhabitacion = numhabitacion;
    }

    public Historial_hotel getNext() {
        return next;
    }

    public void setNext(Historial_hotel next) {
        this.next = next;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getLlegada() {
        return llegada;
    }

    public void setLlegada(String llegada) {
        this.llegada = llegada;
    }

    public int getNumhabitacion() {
        return numhabitacion;
    }

    public void setNumhabitacion(int numhabitacion) {
        this.numhabitacion = numhabitacion;
    }

    public Historial_hotel getLeft() {
        return left;
    }

    public void setLeft(Historial_hotel left) {
        this.left = left;
    }

    public Historial_hotel getRight() {
        return right;
    }

    public void setRight(Historial_hotel right) {
        this.right = right;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }
}
