/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EDD;

/**
 *
 * @author tomas
 */
public class Habitaciones {
    
    int numhabitacion;
    String tipohabitacion;
    int piso;
    boolean ocupado = false;
    
    public Habitaciones (int numhabitacion, String tipohabitacion, int piso, boolean ocupado){
        this.numhabitacion = numhabitacion;
        this.tipohabitacion = tipohabitacion;
        this.piso = piso;
        this.ocupado = ocupado;
    }

    public int getNumhabitacion() {
        return numhabitacion;
    }

    public void setNumhabitacion(int numhabitacion) {
        this.numhabitacion = numhabitacion;
    }

    public String getTipohabitacion() {
        return tipohabitacion;
    }

    public void setTipohabitacion(String tipohabitacion) {
        this.tipohabitacion = tipohabitacion;
    }

    public int getPiso() {
        return piso;
    }

    public void setPiso(int piso) {
        this.piso = piso;
    }

    public boolean isOcupado() {
        return ocupado;
    }

    public void setOcupado(boolean ocupado) {
        this.ocupado = ocupado;
    }
}
